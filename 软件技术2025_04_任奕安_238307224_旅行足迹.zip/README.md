# safetyshare.github.io
致钟莲老师：
   此仓库为本人人工智能作业，如需要请自行下载。